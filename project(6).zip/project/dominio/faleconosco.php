<!DOCTYPE html>
<html lang="pt-br">

<!-- Aba head contém as informações sobre o cabeçalho-->

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Texto que aparece na aba do navegador-->
    <title>FALE CONOSCO</title>
    <meta charset="utf-8">
    <!-- Aba style é feita em CSS, para modificar os estilos da página-->
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
    <!--Link para o CSS escrito em aba separada-->
    <style>
        div.contato {
            display: inline-block;
            width: 10%;
        }

        div.Contatos {
            width: 100%;
            text-align: center;
        }

        .Formulario {
            width: 60%;
            margin-left: auto;
            margin-right: auto;
        }

        form {
            box-shadow: 5px 10px 10px #fab95b;
            border: outset 10px #f16821;
        }
    </style>

</head>

<!-- Aba body é o corpo / conteúdo da página-->

<body>
    <script>
        function validaForm() {
            var nome = document.forms["myForm"]["NOME"].value;
            var idade = document.forms["myForm"]["IDADE"].value;
            var email = document.forms["myForm"]["EMAIL"].value;
            var telefone = document.forms["myForm"]["TELEFONE"].value;
            var titulo = document.forms["myForm"]["TITULO"].value;
            var sexo = document.forms["myForm"]["SEXO"].value;
            var solicitante = document.forms["myForm"]["SOLICITANTE"].value;
            var descricao = document.forms["myForm"]["DESCRIÇÃO"].value;

            switch ("") {
                case nome:
                    alert("Por favor, preencha o campo 'Nome'.");
                    return false;
                case idade:
                    alert("Por favor, preencha o campo 'Idade'.");
                    return false;
                case email:
                    alert("Por favor, preencha o campo 'E-mail'.");
                    return false;
                case telefone:
                    alert("Por favor, preencha o campo 'Telefone'.");
                    return false;
                case titulo:
                    alert("Por favor, preencha o campo 'Assunto'.");
                    return false;
                case sexo:
                    alert("Por favor, selecione uma opção para 'Gênero'.");
                    return false;
                case solicitante:
                    alert("Por favor, selecione uma opção para 'Quem é você?'");
                    return false;
                case descricao:
                    alert("Por favor, preencha o campo 'Descrição'.");
                    return false;
                default:
                    return true;
            }
        }
    </script>
    <?php include('header.php'); ?>
    <!-- Classe "Todo_conteudo" criada para armazenar todo o conteúdo da página-->
    <div class="Todo_conteudo">
        <!-- Classe "Titulo" criada para o título-->
        <div class="Titulo">
            <br>
            <h1>
                <center>ENTRE EM CONTATO COM A CoLabNeT</center>
            </h1>
            <hr>
        </div>
        <br><br><br><Br>
        <!-- Classe "Contatos" criada para armazenar e gerenciar tudo sobre os contatos-->
        <div class="Contatos">
            <h1>
                <center>CONTATOS</center>
            </h1>
            <br><br><br><Br>
            <!-- Classe "Link_de_contatos" criada para armazenar e gerenciar os links de contatos -->

            <div class="Link_de_contatos">
                <div style="text-align: center;">
                    <div class="contato">
                        <a href="https://www.instagram.com/" target="_blank"><img src="img/Instagram.png" height="100" width="100"></a><br>
                        INSTAGRAM
                    </div>
                    <div class="contato">
                        <a href="https://web.whatsapp.com/" target="_blank"><img src="img/WhatsApp.png" height="100" width="100"></a><br>
                        WHATSAPP
                    </div>
                    <div class="contato">
                        <a href="https://mail.google.com/" target="_blank"><img src="img/email.png" height="100" width="100"></a><br>
                        E-MAIL
                    </div>
                    <div class="contato">
                        <a href="tel:+5500000-0000" target="_blank"><img src="img/telefone.jpg" height="100" width="100"></a><br>
                        TELEFONE
                    </div>
                </div>
                <br><br><br><Br>
            </div>
            <!-- Classe "Formulario" criada para o formulário de contato -->
            <div class="Formulario">
                <h2>
                    <center> Se preferir, preencha o formulário abaixo e<br>
                        entraremos em contato com você.</center>
                </h2>
                <br><br><br><br>
                <!-- Conteúdo do formulário-->
                <form name="myForm" action="pagina.php" onsubmit="return validaForm()" method="post" style="text-align: center;">
                    <fieldset style="text-align: center;">
                        <h2>FORMULÁRIO PARA CONTATO<br></h2>
                        NOME COMPLETO* : <input type="text" name="NOME" size="50" />
                        IDADE* : <input type="text" name="IDADE" size="3" /><br><br>
                        E-MAIL* : <input type="email" name="EMAIL" size="40" />
                        TELEFONE* : <input type="tel" name="TELEFONE" size="20" maxlength="11" /><br><br>
                        ASSUNTO* : <input type="text" name="TITULO" size="80" maxlength="20" /><br><br>
                        <div>
                            <label for="SEXO">GÊNERO* :</label>
                            <select id="SEXO" name="SEXO">
                                <option value=""></option>
                                <option value="FEMININO">FEMININO</option>
                                <option value="MASCULINO">MASCULINO</option>
                                <option value="NAO_INFORMAR">PREFIRO NÃO INFORMAR</option>
                            </select>

                            <label for="SOLICITANTE" style="margin-left: 120px;"> QUEM É VOCÊ* ? </label>
                            <select id="SOLICITANTE" name="SOLICITANTE">
                                <option value=""></option>
                                <option value="COLABORADOR">COLABORADOR</option>
                                <option value="EMPRESA">EMPRESA</option>
                            </select>
                        </div><br>
                        <label for="Descrição">
                            <center>DESCREVA SUA NECESSIDADE* :</center>
                        </label><textarea name="DESCRIÇÃO" cols="90" rows="10"></textarea><br><br>
                        <input class="botao2" type="submit" value="Enviar" />
                        <input class="botao2" type="reset" value="Refazer" /><br>
                    </fieldset>
                </form>
                <br><br><br><Br>
            </div>

        </div>

    </div>

</body>

<!-- Aba criada para as informações finais da página, sempre se manterá no inferior dela-->
<section>
    <!-- Qualquer conteúdo que dêva ser mantido ao final da página, porém antes dos links de movimentação 
    entre as páginas, deve ser acrescentado logo após este comentário-->
    <!-- Classe "Final_da_pagina" criada para aos links inferiores da página-->
    <div class="Final_da_pagina">



        <?php include('footer.php'); ?>

</section>

<!-- Aba referente ao rodapé, utilizada normalmente para colocar imformaçÕes de fontes e construtores do site-->
<footer>
    <!-- Classe "rodape" criada para armazenar e manipular o radapé-->
    <div class="rodape" style="text-align: right;">
        Fundadores Guilherme / Mayara / Ricardo / Sílvia
    </div>
    <!-- FIM DO RODAPÉ-->
</footer>

<!-- FIM DA PÁGINA COMPLETA-->


</html>