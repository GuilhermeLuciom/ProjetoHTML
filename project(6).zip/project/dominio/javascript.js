var x =10;
document.getElementById("Titulo").innerHTML = x;
