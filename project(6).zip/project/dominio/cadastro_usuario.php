<?php 
  session_start();

  if(isset($_POST["nome"], $_POST["nivel_privilegio"], $_POST["senha"])) {
    // Criando a conexão com o banco de dados e selecionando o banco de dados
    $conexao = mysqli_connect("localhost", "root", "", "aplicacaoweb");
    
    if($conexao) {
      // Preparando os dados para inserção no banco
      $nome = $_POST["nome"];
      $nivel_privilegio = $_POST["nivel_privilegio"];
      $senha = hash('sha256', $_POST["senha"]); // Armazene senhas de forma segura!

      // Preparando e executando a consulta de inserção
      $comando = "INSERT INTO usuario (Nome, Nivel_Privilegio, Senha) VALUES ('$nome', '$nivel_privilegio', '$senha')";
      $resultado = mysqli_query($conexao, $comando);
      
      if($resultado) {
        echo "Usuário cadastrado com sucesso!";
      } else {
        echo "Erro não cadastrar usuário. Por favor, tente novamente.";
      }
    }
  }
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastrar Usuario</title>
  <link rel="stylesheet" href="ecommerce.css" type="text/css">
</head>

<body style="Position: absolute;top: 25%;width: 97%;text-align: center;font-size: 18px;">
  <?php if (isset($_SESSION["logado"]) && $_SESSION["logado"] == true) {
  ?>

    <h2>Cadastro de Usuário</h2>
    <form action="cadastro_usuario.php" method="post" style="margin-left: 50px; text-align: center;">
      Nome:<input type="text" name="nome" required size="40"/> <br><br>
      Nível de Privilégio:<input type="text" name="nivel_privilegio" required size="27" /> <br><br>
      Senha:<input type="password" name="senha" required size="40"/> <br><br><br><br>
      <input style="margin-left: 30px;" class="botao1" type="submit" value="CADASTRAR" />
      <a  href='paginainicial.php' target='_self'><input class='botao1' type='button' value='PÁGINA INICIAL'></a>
    </form>
  <?php
  } ?>
</body>

</html>