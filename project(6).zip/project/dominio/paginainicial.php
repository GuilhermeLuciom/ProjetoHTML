<!DOCTYPE html>
<html lang="pt-br">

<!-- Aba head contém as informações sobre o cabeçalho-->

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Texto que aparece na aba do navegador-->
    <title>PÁGINA INICIAL</title>
    <meta charset="utf-8">
    <!--Configura a linguagem de escrita para utilizarmos acentuação-->
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
    <!--Link para o CSS escrito em aba separada-->
    <style>
        .colunadireita {
            float: left;
            width: 70%;
            background-color: #f6efe8;
            margin-top: 50px;
        }

        .colunaesquerda {
            padding: 11px;
            padding-bottom: 95px;
            margin-top: 50px;
            float: right;
            width: 28%;
            background-color: #f6efe8;
        }

        .Todo_conteudo::after {
            content: "";
            display: table;
            clear: both;
        }

        @media screen and (max-width: 800px) {

            .colunadireita,
            .colunaesquerda {
                width: 100%;
                padding: 0;
            }
        }
    </style>
</head>

<body>
    <div style="position: absolute; width: 200px; height:200px; right:50px; top:40px;">
        <?php include "login.php" ?>
    </div>
    <?php include('header.php'); ?>
    <!-- Classe "Todo_conteudo" criada para armazenar todo o conteúdo da página-->
    <div class="Todo_conteudo">
        <!-- Classe "Noticia" criada para apresentar as notícias-->
        <div class="colunadireita">
            <center>
                <p style="text-align:left; font-size: 15px;">Notícia (1)</p>

                <h2 id="noticiadestaque1" class="titulo_noticia" style="font-size: 30px; width: 90%;">
                    O crescimento do mercado de TI e a crescente demanda por profissionais da área
                </h2>
                <hr><br><br>

                <a href="https://gizmodo.uol.com.br/o-crescimento-do-mercado-de-ti-e-a-crescente-demanda-por-profissionais-da-area/amp/" target="_blank"><img src="img/noticia/noticia.jpg" height="50%" width="40%"></a>


                <p>O mercado de TI cresce exponencialmente a cada ano, provando ser promissor para os profissionais do
                    nicho. No entanto, a formação de profissionais e especialistas não acompanhou tal evolução, causando
                    um déficit de mão de obra capacitada na área. Esse problema não é novo e vem alarmando empresas no
                    setor de tecnologia e inovação. Sendo […]</p>
                <P>
                    O mercado de TI cresce exponencialmente a cada ano, provando ser promissor para os profissionais do
                    nicho. No entanto, a formação de profissionais e especialistas não acompanhou tal evolução, causando
                    um déficit de mão de obra capacitada na área. Esse problema não é novo e vem alarmando empresas no
                    setor de tecnologia e inovação.</P>
                <p>

                    Sendo considerada uma profissão-chave e que exige conhecimentos específicos, a carreira de um
                    especialista em TI é necessária para o desenvolvimento de sistemas cotidianos (utilizados
                    majoritariamente por outras áreas de atuação) e pela segurança de informação, que atua na proteção
                    dos nossos dados em uma sociedade completamente tecnológica.</p>
                <p>
                    Uma pesquisa realizada em 2020 pela Associação Brasileira das Empresas de Tecnologia da Informação e
                    Comunicação (Brasscom) diz que até o ano de 2024 o Brasil precisará de cerca de 420 mil
                    profissionais na área de Tecnologia da Informação. Porém, por ano, a mesma pesquisa diz que o país
                    forma apenas 46 mil profissionais capacitados no nicho.</p>
                <P style="text-align: right;font-size: 15px;"><a href="https://gizmodo.uol.com.br/o-crescimento-do-mercado-de-ti-e-a-crescente-demanda-por-profissionais-da-area/amp/" target="_blank">SAIBA MAIS</a></P>
            </center>
            <br><br>
            <center>
                <p style="text-align:left; font-size: 15px;">Noticia (2)</p>

                <h2 id="noticiadestaque2" class="titulo_noticia" style="font-size: 30px;">
                    A importância de uma equipe de TI qualificada
                </h2>
                <hr><br><br>

                <a href="https://blog.saphir.com.br/a-importancia-de-uma-equipe-de-ti-qualificada/" target="_blank"><img src="img/noticia/Blog-Imagens-Destacadas-6.jpg" height="60%" width="50%"></a>

                <p>
                    Ter uma equipe de TI qualificada é de extrema importância para qualquer empresa. Afinal, a
                    tecnologia tem um papel cada vez mais central na forma como as empresas operam e interagem com seus
                    clientes.</p>
                <p>

                    Quando falamos em tecnologia como setor, a atenção é ainda maior. Muitas áreas estão expandido
                    rapidamente, incluindo a inteligência artificial, a Internet das Coisas e a segurança cibernética. À
                    medida que o setor cresce, a demanda por profissionais de TI também aumenta, mas nem sempre há
                    profissionais suficientes para preencher as vagas.</p>

                <P style="text-align: right; font-size: 15px;"><a href="https://blog.saphir.com.br/a-importancia-de-uma-equipe-de-ti-qualificada/" target="_blank">SAIBA MAIS</a></P>
                <br><br>
                <hr><br><br>

            </center>
        </div>

        <div class="colunaesquerda">
            <p style="margin: 40px;">
                Por conta da demandas do mercado para proficionais da Tecnologia de informação, a <span>CoLabNeT</span>
                é um projeto para incentivar o
                mercado na contratação de futuros profissionais na área de Tecnologia da Informação, tanto
                acadêmicos que estão iniciando os estudos, quanto aqueles que já estão finalizando seu curso.
                Como por exemplo:
            </p>
            <div class="colaborador">

                <!-- Classe "Noticia" criada para apresentar as notícias-->
                <div class="colunadireita" style="text-align: center; width: 100%; ">
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "aplicacaoweb";

                    // Criação da conexão
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Verificação da conexão
                    if ($conn->connect_error) {
                        die("Falha na conexão: " . $conn->connect_error);
                    }

                    $sql = "SELECT Id_produto, nome, descricao, custo, curriculo, foto, Pru_destaque FROM produto WHERE Pru_destaque = 1";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<div class="colaborador">';
                            echo '<div style="text-align: center;">';
                            echo '<a href="' . $row['curriculo'] . '" target="_blank"><img src="' . $row['foto'] . '" height="272" width="184"></a>';
                            echo '<h2>' . $row['nome'] . '</h2>';
                            echo '<p2>' . $row['descricao'] . '</p2>';
                            echo '<br>';
                            echo '<br><br>';
                            echo '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo "Nenhum produto destacado encontrado.";
                    }

                    $conn->close();
                    ?>


                </div>
            </div>
        </div>
        
        

        <!-- Aba referente ao rodapé, utilizada normalmente para colocar imformaçÕes de fontes e construtores do site-->
        <footer>
            <!-- Classe "rodape" criada para armazenar e manipular o radapé-->
            <div class="rodape" style="text-align: right;">
                Fundadores Guilherme / Mayara / Ricardo / Sílvia
            </div>
            <!-- FIM DO RODAPÉ-->
        </footer>

        <!-- FIM DA PÁGINA COMPLETA-->
         <BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
         <BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
         <BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
        <?php include('footer.php'); ?>
</body>

</html>