<?php
session_start();

// Verificar se o usuário não está autenticado e redirecionar para a página de login
if (!isset($_SESSION["logado"]) || $_SESSION["logado"] !== true) {
    header("Location: paginainicial.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aplicacaoweb";

// Conexão com o Banco de Dados
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Adicionar Produto
if (isset($_POST['addProduct'])) {
    $ProdutoNome = $_POST['ProdutoNome'];
    $ProdutoDescricao = $_POST['ProdutoDescricao'];
    $ProdutoCusto = $_POST['ProdutoCusto'];
    $ProdutoCurriculo = $_POST['ProdutoCurriculo'];
    $ProdutoFoto = $_POST['ProdutoFoto'];
    $ProdutoDestaque = $_POST['ProdutoDestaque'];

    $sql = "INSERT INTO produto (nome, descricao, custo , curriculo , foto , Pru_destaque) VALUES ('$ProdutoNome', '$ProdutoDescricao', '$ProdutoCusto' , '$ProdutoCurriculo' , '$ProdutoFoto' , '$ProdutoDestaque')";

    if ($conn->query($sql) === TRUE) {
        echo "Novo produto adicionado com sucesso!";
    } else {
        echo "Erro ao adicionar produto: " . $conn->error;
    }
}

// Editar Produto
if (isset($_POST['EditarProduto2'])) {
    $ProdutoID = $_POST['ProdutoID'];
    $ProdutoNome = $_POST['ProdutoNome'];
    $ProdutoDescricao = $_POST['ProdutoDescricao'];
    $ProdutoCusto = $_POST['ProdutoCusto'];
    $ProdutoCurriculo = $_POST['ProdutoCurriculo'];
    $ProdutoFoto = $_POST['ProdutoFoto'];
    $ProdutoDestaque = $_POST['ProdutoDestaque'];

    $sql = "UPDATE produto SET nome='$ProdutoNome', descricao='$ProdutoDescricao', custo='$ProdutoCusto' , curriculo='$ProdutoCurriculo' , foto='$ProdutoFoto' , Pru_destaque='$ProdutoDestaque'  WHERE Id_produto='$ProdutoID'";

    if ($conn->query($sql) === TRUE) {
        echo "Produto atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar produto: " . $conn->error;
    }
}

// Excluir Produto
if (isset($_POST['ExcluirProduto'])) {
    $ProdutoID = $_POST['ProdutoID'];

    $sql = "DELETE FROM produto WHERE Id_produto='$ProdutoID'";

    if ($conn->query($sql) === TRUE) {
        echo "Produto excluído com sucesso!";
    } else {
        echo "Erro ao excluir produto: " . $conn->error;
    }
}

// Exibir Produtos Existente
$sql = "SELECT * FROM produto";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Produtos</title>
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
</head>

<body>
    <?php include('header.php'); ?>
    <?php if (isset($_POST['EditarProduto'])) : 
        $ProdutoID = $_POST['ProdutoID'];
        $sql_edit = "SELECT * FROM produto WHERE Id_produto='$ProdutoID'";
        $result_edit = $conn->query($sql_edit);
        if ($result_edit->num_rows > 0) {
            $row_edit = $result_edit->fetch_assoc();
    ?>
            <br><br>
            <h2 style="text-align: center;">Editar Produto</h2><br><br>
            <form method="post" action="">
                <label for="ID">ID do produto:</label>
                <input type="text" name="ProdutoID" value="<?php echo $row_edit['Id_produto']; ?>">
                <label for="ProdutoNome">Nome do Produto:</label>
                <input type="text" id="ProdutoNome" name="ProdutoNome" value="<?php echo $row_edit['nome']; ?>">
                <label for="ProdutoDescricao">Descrição:</label>
                <input type="text" id="ProdutoDescricao" name="ProdutoDescricao" value="<?php echo $row_edit['descricao']; ?>">
                <label for="ProdutoCusto">Custo:</label>
                <input type="text" id="ProdutoCusto" name="ProdutoCusto" value="<?php echo $row_edit['custo']; ?>">
                <label for="ProdutoCurriculo">Curriculo:</label>
                <input type="text" id="ProdutoCurriculo" name="ProdutoCurriculo" value="<?php echo $row_edit['curriculo']; ?>">
                <label for="ProdutoFoto">Foto:</label>
                <input type="text" id="ProdutoFoto" name="ProdutoFoto" value="<?php echo $row_edit['foto']; ?>">
                <label for="ProdutoDestaque">Produto Destaque:</label>
                <input type="text" id="ProdutoDestaque" name="ProdutoDestaque" value="<?php echo $row_edit['Pru_destaque']; ?>"><br><br><br><br><br><br>
                <input type="submit" name="EditarProduto2" style="margin-left: 44%;" class="botao1" value="Editar Produto">
            </form>
    <?php 
        } else {
            echo "Produto não encontrado.";
        }
    ?>
    <?php endif; ?>

    <br><Br>
    <h2 style="text-align: center;">Adicionar Novo Produto</h2><br><br>
    <form method="post" action="">
        <label style="margin-left: 8%;" for="ProdutoNome">Nome do Produto:</label>
        <input type="text" id="ProdutoNome" name="ProdutoNome">
        <label for="ProdutoDescricao">Descrição:</label>
        <input type="text" id="ProdutoDescricao" name="ProdutoDescricao">
        <label for="ProdutoCusto">Custo:</label>
        <input type="text" id="ProdutoCusto" name="ProdutoCusto">
        <label for="ProdutoCurriculo">Curriculo:</label>
        <input type="text" id="ProdutoCurriculo" name="ProdutoCurriculo">
        <label for="ProdutoFoto">Foto:</label>
        <input type="text" id="ProdutoFoto" name="ProdutoFoto">
        <label for="ProdutoDestaque">Produto Destaque:</label>
        <input type="text" id="ProdutoDestaque" name="ProdutoDestaque"><br><br><br><br>
        <input type="submit" name="addProduct" style="margin-left: 44%;" class="botao1" value="Adicionar Produto"><br><br>
    </form>

    <h2>Lista de Produtos</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Descrição</th>
            <th>Custo</th>
            <th>Curriculo</th>
            <th>Foto</th>
            <th>Produto Destaque</th>
            <th>Ações</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["Id_produto"] . "</td>";
                echo "<td>" . $row["nome"] . "</td>";
                echo "<td>" . $row["descricao"] . "</td>";
                echo "<td>R$ " . $row["custo"] . "</td>";
                echo "<td>" . $row["curriculo"] . "</td>";
                echo "<td>" . $row["foto"] . "</td>";
                echo "<td>" . $row["Pru_destaque"] . "</td>";
                echo '<td>
                        <form method="post" action="">
                            <input type="hidden" name="ProdutoID" value="' . $row["Id_produto"] . '">
                            <input type="submit" name="EditarProduto" value="Editar">
                            <input type="submit" name="ExcluirProduto" value="Excluir">
                        </form>
                    </td>';
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhum produto encontrado</td></tr>";
        }
        ?>
    </table>

    </table>

    <?php include('footer.php'); ?>
</body>

</html>