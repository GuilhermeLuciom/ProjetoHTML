<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COLABORADORES</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
    <style>
        /* Seus estilos CSS aqui */
    </style>
</head>

<body>
    <div class="cabeçalho">
        <div class="Logo">
            <a href="paginainicial.php" target="_self"><img src="img/logo.gif" height="300" width="300"></a>
        </div>
    </div>

    <div class="Link_superior">
        <a href="colabnet.php" target="_self"><input class="botao1" type="button" value="SOBRE NÓS"></a>
        <a href="paginainicial.php" target="_self"><input class="botao1" type="button" value="PÁGINA INICIAL"></a>
        <a href="colaboradores.php" target="_self"><input class="botao1" type="button" value="COLABORADORES"></a>
        <a href="faleconosco.php" target="_self"><input class="botao1" type="button" value="FALE CONOSCO"></a>
        <a href="carrinho.php" target="_self"><input class="botao1" type="button" value="SELECIONADOS"></a>
    </div>