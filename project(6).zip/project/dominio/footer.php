<section>
        <div class="link_inferior">
            <div class="Final_da_pagina">
                <div class="Dados" style="text-align: center;">
                    <h5>contato@colabnet.com.br</h5>
                    <h5>Endereço: Rua Erê, 207 - Lab 7 Bairro: Prado Cidade: Belo Horizonte</h5>
                    <h5>Telefone : (31) 9 9900-2233</h5>
                </div>
                <div style="text-align: center;margin-top: 50px;">
                    <a href="colabnet.php" target="_self"><input class="botao1" type="button" value="SOBRE NÓS"></a>
                    <a href="paginainicial.php" target="_self"><input class="botao1" type="button" value="PÁGINA INICIAL"></a>
                    <a href="colaboradores.php" target="_self"><input class="botao1" type="button" value="VOLTAR AO TOPO"></a>
                    <a href="faleconosco.php" target="_self"><input class="botao1" type="button" value="FALE CONOSCO"></a>
                    <a href="carrinho.php" target="_self"><input class="botao1" type="button" value="SELECIONADOS"></a>
                    <br><br><br><br>
                </div>
            </div>
        </div>
    </section>
</body>

<footer>
    <div class="rodape" style="text-align: right;">
        Fundadores Guilherme / Mayara / Ricardo / Sílvia
    </div>
</footer>

</html>