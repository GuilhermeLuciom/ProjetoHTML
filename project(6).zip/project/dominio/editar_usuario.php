<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION["logado"]) || $_SESSION["logado"] !== true) {
    header("Location: paginainicial.php");
    exit;
}

// Verificar se o ID do usuário foi passado via GET
if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    echo "ID de usuário inválido.";
    exit;
}

// Conectar ao banco de dados
$conexao = mysqli_connect("localhost", "root", "", "aplicacaoweb");

if (!$conexao) {
    echo "Erro ao conectar ao banco de dados.";
    exit;
}

// Preparar o ID do usuário
$id_usuario = $_GET["id"];

// Preparar e executar a consulta SQL para obter os dados do usuário
$comando = "SELECT * FROM usuario WHERE Id_usuario = $id_usuario";
$resultado = mysqli_query($conexao, $comando);

if (!$resultado) {
    echo "Erro ao consultar o banco de dados.";
    exit;
}

// Verificar se o usuário foi encontrado
if (mysqli_num_rows($resultado) == 0) {
    echo "Usuário não encontrado.";
    exit;
}

// Obter os dados do usuário
$usuario = mysqli_fetch_assoc($resultado);

// Verificar se o formulário de edição foi submetido
if (isset($_POST["nome"], $_POST["nivel_privilegio"], $_POST["senha"])) {
    // Obter os dados do formulário
    $nome = $_POST["nome"];
    $nivel_privilegio = $_POST["nivel_privilegio"];
    $senha = hash('sha256', $_POST["senha"]); // Hash da senha antes de salvar no banco de dados

    // Preparar e executar a consulta SQL para atualizar o usuário
    $comando_atualizar = "UPDATE usuario SET Nome = '$nome', Nivel_privilegio = '$nivel_privilegio', Senha = '$senha' WHERE Id_usuario = $id_usuario";
    $resultado_atualizar = mysqli_query($conexao, $comando_atualizar);

    if ($resultado_atualizar) {
        echo "Usuário atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar usuário: " . mysqli_error($conexao);
    }
}

// Fechar a conexão
mysqli_close($conexao);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário</title>
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
</head>
<body style="position: absolute;top: 25%;width: 98%;text-align: center;font-size: 18px;">
    <h2>Editar Usuário</h2>
    <form style="margin-left: 30px;" action="editar_usuario.php?id=<?php echo $id_usuario; ?>" method="post">
        Nome: <input type="text" name="nome" value="<?php echo $usuario['Nome']; ?>" required size="40"><br><br>
        Nível de Privilégio: <input type="text" name="nivel_privilegio" value="<?php echo $usuario['Nivel_privilegio']; ?>" required size="27"><br><br>
        Senha: <input type="password" name="senha" required size="40"><br><br><br>
        <input class="botao1" type="submit" value="ATUALIZAR">
        <a href="paginainicial.php" target="_self"><input class="botao1" type="button" value="PAGINA INICIAL"></a>
    </form>
    <br>
</body>
</html>