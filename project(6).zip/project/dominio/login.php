<?php 
session_start();

// Inicializar a variável $usuario para evitar erros caso o usuário não esteja autenticado
$usuario = null;

// Verificar se o formulário de login foi enviado
if(isset($_POST["login"]) && isset($_POST["Senha"])) {
    // Criar a conexão com o banco de dados e selecionar o banco de dados
    $conexao = mysqli_connect("localhost", "root", "", "aplicacaoweb");
    
    if($conexao) {
        // Retorna usuário
        $comando = "SELECT * FROM usuario WHERE Nome = '" . $_POST["login"] . "'";
        $resultado = mysqli_query($conexao, $comando);
        
        // Verificar se o resultado da consulta está vazio
        if(mysqli_num_rows($resultado) > 0) {
            $usuario = mysqli_fetch_object($resultado);
            
            // Verificar login e senha  
            if($usuario && hash('sha256', $_POST["Senha"]) == $usuario->Senha) {
                $_SESSION["logado"] = true;
                $_SESSION["login"] = $usuario->Nome; // Definir $_SESSION["login"] com o nome de usuário
                $_SESSION["id_usuario"] = $usuario->Id_usuario; // Definir $_SESSION["id_usuario"] com o ID do usuário
            }
        }
    }
}

// Verificar se o usuário deseja fazer logout
if(isset($_GET["logout"]) && $_GET["logout"] == true) {
    unset($_SESSION["logado"]);
    unset($_SESSION["login"]); // Remover $_SESSION["login"] ao fazer logout
    unset($_SESSION["id_usuario"]); // Remover $_SESSION["id_usuario"] ao fazer logout
    session_destroy();
}

// Buscar o ID do usuário novamente se ele não estiver autenticado ou se $usuario estiver definido como null
if (isset($_SESSION["logado"]) && $_SESSION["logado"] == true && !isset($_SESSION["id_usuario"])) {
    // Verificar se $_SESSION["login"] está definido
    if (isset($_SESSION["login"])) {
        // Criar a conexão com o banco de dados
        $conexao = mysqli_connect("localhost", "root", "", "aplicacaoweb");
        
        // Verificar se a conexão foi estabelecida com sucesso
        if($conexao) {
            // Consultar o banco de dados para obter o usuário atualizado com base no Nome armazenado na sessão
            $comando = "SELECT * FROM usuario WHERE Nome = '" . $_SESSION["login"] . "'";
            $resultado = mysqli_query($conexao, $comando);
            
            // Verificar se o resultado da consulta está vazio
            if(mysqli_num_rows($resultado) > 0) {
                $usuario = mysqli_fetch_object($resultado);
                
                // Verificar se o usuário está definido e se possui a propriedade Id_usuario antes de tentar acessá-la
                if($usuario !== null && property_exists($usuario, 'Id_usuario')) {
                    $_SESSION["id_usuario"] = $usuario->Id_usuario; // Armazenar o ID do usuário na sessão
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
</head>
<body>
<?php if (isset($_SESSION["logado"]) && $_SESSION["logado"] == true) {
    echo "<span>Usuário Autenticado</span><br><br>";
    // Verificar se o usuário está definido e se possui a propriedade Id_usuario antes de tentar acessá-la
    echo "<a href='editar_usuario.php?id=" . $_SESSION["id_usuario"] . " 'class='botao1' style='width:200px;text-align: center;'><br>EDITAR USUARIO</a>";
    echo "<a href='edIcao_produto.php 'class='botao1' style='width:200px;text-align: center;'><br>EDIÇÃO DE PRODUTO</a>";
    echo "<a href='cadastro_usuario.php 'class='botao1' style='width:200px;text-align: center;'><br>CADASTRAR USÚARIO</a>";
    echo "<a href='paginainicial.php ?logout=true' class='botao1' style='width:200px;text-align: center;'><br>SAIR</a>";
   
} else {
?>
  
    <form action="paginainicial.php" method="post" >
      LOGIN:<input type="text" name="login" /> <br> <!-- Alterado para "login" -->
      SENHA:<input type="password" name="Senha" /> <br>
      <input class="botao2" type="submit" value="Autenticar" />
    </form>
<?php
} ?>
</body>
</html>