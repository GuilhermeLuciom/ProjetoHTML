<?php
session_start(); // Inicia a sessão

// Função para adicionar produto ao carrinho
function addToCart($productId, $productName, $productImage, $productCost)
{
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }
    // Adiciona o produto ao carrinho
    $_SESSION['cart'][$productId] = array(
        'name' => $productName,
        'image' => $productImage,
        'cost' => $productCost
    );
}

// Verifica se o produto foi adicionado ao carrinho
if (isset($_POST['addToCart'])) {
    $productId = $_POST['productId'];
    $productName = $_POST['productName'];
    $productImage = $_POST['productImage'];
    $productCost = $_POST['productCost'];
    addToCart($productId, $productName, $productImage, $productCost);
    // Salva a posição atual da página
    $_SESSION['scroll_position'] = $_POST['scrollPosition'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Texto que aparece na aba do navegador-->
    <title>COLABORADORES</title>
    <meta charset="utf-8">
    <!-- Aba style é feita em CSS, para modificar os estilos da página-->
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
    <!--Link para o CSS escrito em aba separada-->
    <style>
        .flex-Colaboradores {
            display: flex;
            background-color: #f8f7f5;
            width: 90%;
            flex-wrap: wrap;
            float: right;
            margin: 100px;
        }

        .flex-Colaboradores>div {
            background-color: #f4d7af;
            align-items: center;
            margin: 50px;
            width: 300px;
            padding: 30px;
            margin-left: 5%;
        }

        .selecionar {
            color: #1a3263;
            background-color: #f16821;
            width: 200px;
            height: 50px;
            box-shadow: 10px 10px 15px #1a3263;
            margin: 40px;
            font-size: 18px;
        }

        .flex-Colaboradores>div:hover {
            color: #1a3263;
            background-color: #fab95b;
        }

        .selecionar:hover {
            background-color: #1a3263;
            color: #f16821;
        }

        p2 {
            color: #1a3263;
        }

        .custo-quadrado {
            border: 1px solid #ccc;
            padding: 10px;
            display: inline-block;
        }
    </style>
</head>

<body>
    <?php include('header.php'); ?>
    <div class="Todo_conteudo">
        <div class="Titulo">
            <br>
            <h1>
                <center>CONHEÇA NOSSOS COLABORADORES</center>
            </h1>
            <hr>
        </div>

        <div class="flex-Colaboradores">
            <br><br><br><br>
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "aplicacaoweb";

            // Criação da conexão
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Verificação da conexão
            if ($conn->connect_error) {
                die("Falha na conexão: " . $conn->connect_error);
            }

            $sql = "SELECT Id_produto, nome, descricao, custo, curriculo, foto FROM produto";
            $resultado = $conn->query($sql);

            if ($resultado->num_rows > 0) {
                while ($colaborador = $resultado->fetch_assoc()) {
                    $produtoCusto = $colaborador['custo'] . ",00"; // Adiciona ",00" ao custo
                    echo '<div class="colaborador2">';
                    echo '<div style="text-align: center;">';
                    echo '<a href="' . $colaborador['curriculo'] . '" target="_blank"><img src="' . $colaborador['foto'] . '" height="272" width="184"></a>';
                    echo '<h2>' . $colaborador['nome'] . '</h2>';
                    echo '<p2>' . $colaborador['descricao'] . '</p2><br><br><br>';
                    echo '<div class="custo-quadrado">'; // Div para o custo
                    echo '<p2>Custo: R$ ' . $produtoCusto . '</p2>'; // Mostra o custo com ",00"
                    echo '</div>'; // Fecha a div custo-quadrado
                    echo '<br>';
                    echo '<form method="post" action="">'; // Ação aponta para a própria página
                    echo '<input type="hidden" name="productId" value="' . $colaborador['Id_produto'] . '">';
                    echo '<input type="hidden" name="productName" value="' . $colaborador['nome'] . '">';
                    echo '<input type="hidden" name="productImage" value="' . $colaborador['foto'] .'">';
                    echo '<input type="hidden" name="productCost" value="' . $produtoCusto . '">';
                    echo '<input type="hidden" name="scrollPosition" value="' . $_SESSION['scroll_position'] . '">';
                    echo '<input class="selecionar" type="submit" name="addToCart" value="SELECIONAR" />';
                    echo '</form>';
                    echo '<br><br>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo "Nenhum produto encontrado.";
            }

            $conn->close();
            ?>
        </div>
    </div>

    <?php include('footer.php'); ?>

</body>

<footer>
    <div class="rodape" style="text-align: right;">
        Fundadores Guilherme / Mayara / Ricardo / Sílvia
    </div>
</footer>

</html>