from pyspark.sql import SparkSession
from tkinter import Tk, Label, Entry, Button, StringVar

spark = SparkSession.builder \
    .appName("LoginApp") \
    .getOrCreate()

def login():
    username = username_entry.get()
    password = password_entry.get()

    user_exists = spark.sql("SELECT * FROM users WHERE username = '{}' AND password = '{}'".format(username, password)).count() > 0

    if user_exists:
        status.set("Login bem-sucedido!")
    else:
        status.set("Nome de usuário ou senha incorretos.")


root = Tk()
root.title("Login")
root.geometry("400x200")


username_label = Label(root, text="Nome de Usuário:")
username_label.place(relx=0.1, rely=0.3, anchor="w")
username_entry = Entry(root)
username_entry.place(relx=0.4, rely=0.3, anchor="w")

password_label = Label(root, text="Senha:")
password_label.place(relx=0.1, rely=0.4, anchor="w")
password_entry = Entry(root, show="*")
password_entry.place(relx=0.4, rely=0.4, anchor="w")

login_button = Button(root, text="Login", command=login)
login_button.place(relx=0.5, rely=0.5, anchor="center")


status = StringVar()
status_label = Label(root, textvariable=status)
status_label.place(relx=0.5, rely=0.6, anchor="center")

root.mainloop()

spark.stop()
