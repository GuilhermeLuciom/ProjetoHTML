<!DOCTYPE html>
<html lang="pt-br">

<!-- Aba head contém as informações sobre o cabeçalho-->

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Texto que aparece na aba do navegador-->
    <title>COLABNET</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
    <!--Link para o CSS escrito em aba separada-->

</head>

<!-- Aba body é o corpo/conteúdo da página-->

<body>

    <?php include('header.php'); ?>
    <!-- Classe "Todo_conteudo" criada para armazenar todo o conteúdo da página-->
    <div class="Todo_conteudo">

        <!-- Classe "Titulo" criada para o título-->

        <div class="Titulo">
            <br>
            <h1>
                <center>O QUE É A <span>CoLabNeT</span></center>
            </h1>
            <hr>
        </div>
        <!-- Classe "Noticia" fica armazenada as informaçôes sobre o site e seu verdadeiro papel-->
        <p class="Noticia">
            <center>
                <p>
                    <span>CoLabNet</span> é uma plataforma, criada com o intuito de divulgar os alunos dos cursos de
                    graduação na
                    área de Tecnologia da Informação, da Instituição de Ensino Superior: Centro Universitário Estácio
                    de Belo Horizonte. Essa iniciativa surgiu em 2024, da parceria dos então alunos Guilherme Lucio
                    Manasses, Mayara Franco Pimenta, Ricardo Eduardo Soares Do Espirito Santo e Sílvia Nogueira Rausses,
                    indo de encontro com a proposta de projeto da disciplina de Desenvolvimento Web em HTML5, CSS,
                    JAVASCRIPT E PHP, ministrada e orientada pelo Professor Adriano Firmo de Paiva.

                </p>
                <p>
                    Aqui estarão concentrados alunos de todos os períodos, com diferentes objetivos de carreira,
                    diferentes experiências e perfis, mas que possuem em comum, a porcentagem do CR (Coeficiente de
                    Rendimento) superior a 80%.

                </p>
                <p>
                    Muito mais do que uma plataforma de divulgação, o site tem o objetivo de oferecer oportunidades.
                    Ao colocar os alunos em contato virtual com o mercado de trabalho, possibilita aos recrutadores,
                    a partir da análise do perfil que procuram, oferecer uma proposta de serviços da forma como
                    desejarem,
                    seja para contratos por CLT, Estágio, Autônomo, CNPJ ou até mesmo aproveitar a plataforma para
                    convidá-los a participarem de algum projeto específico, no qual os alunos poderão agregar sua
                    participação, como atividade extracurricular.

                </p>
                <p>
                    A plataforma funciona como um meio de conexão das empresas com os alunos, possui vários filtros
                    possíveis para facilitar a classificação e seleção por parte dos recrutadores. Havendo interesse
                    em se conectar com um ou mais alunos, os recrutadores podem clicar no botão “Tenho Interesse” e
                    enviar sua proposta ao(s) aluno(s) por meio do preenchimento de um único formulário, podendo até
                    mesmo anexar arquivos. Após essa seleção, o recrutador envia sua solicitação de conexão e aguarda
                    o(s) aluno(s) retornar(em), caso tenha(m) interesse em continuar com as tratativas da proposta. É
                    permitido selecionar vários alunos ao mesmo tempo, para o mesmo formulário preenchido.

                </p>
                <p>
                <h2>Missão</h2>
                <p>
                    Servir como uma ponte de mão dupla, que liga alunos às milhares de empresas que buscam suprir as
                    necessidades de encontrar profissionais com conhecimentos em Tecnologia. O site é inspirado em
                    tratar com cuidado, respeito e seriedade os dados dos alunos, conforme a LGPD, além de manter sempre
                    o comprometimento com a qualidade na seleção dos alunos, que aqui serão divulgados.
                </p>
        </p>
        <p>
        <H2>Visão</H2>
        <p>
            Tornar uma plataforma de referência internacional, buscando soluções adequadas e inovadoras para
            contribuir com a conexão entre alunos e empresas que precisam de profissionais da área de Tecnologia
            da Informação, além de se tornar um meio de incentivo para que cada vez mais os alunos se qualifiquem
            e consigam estar sempre acima de 80% do CR, aqui exigido para sua seleção.
        </p>
        </p>
        <p>
            <center>
                <H2>Valores</H2>
                <div class="Valores" style="width: 80%; height: 50;">
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Ética</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Honestidade</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Respeito</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Responsabilidade</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Transparência</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Seriedade</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Qualidade</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Cuidado</p>
                    <p style="width: 20%;  display: inline-block;text-align: center;">° Comprometimento</p>
                </div>
        </p>
        </center>
        </p><br><br>
        <hr>
        <!-- Foi criada uma classe para cada fundador, para poder gerir de forma unitária cada usuário. Mas todos 
    estão dentro da classe "Fundadores" para comandos gerais-->
        <div class="Fundadores">
            <h1>FUNDADORES</h1>
            <br><br><br><br>

            <div class="Fund_guilherme">
                <div>
                    <a href="guilherme.html" target="_blank"><img src="Colaboradores/img/Guilherme.png" height="372"
                            width="254" /></a>
                    <h2>
                        <center>Guilherme Lucio</center>
                    </h2>
                    <p>
                        <center>
                            Graduando em Ciências da Computação (Estácio), com previsão
                            de formatura no 1º semestre de 2026. Atualmente é Técnico de
                            de TI no América Futebol Clube, conta com experiências nas
                            áreas de análise de dados, suporte de software, administração
                            e manutenção de redes e integração de equipe, para desenvolver
                            um trabalho analítico, técnico e de comunicação, com perfil
                            produtivo e cooperativo.

                    </p>
                    </center>
                    <br><br><br><br><br>
                </div>
            </div>

            <div class="Fund_mayara">
                <div>
                    <a href="mayra.html" target="_blank"><img src="Colaboradores/img/Mayara.png" height="372"
                            width="254"></a>
                    <h2>
                        <center> Mayara Franco</center>
                    </h2>
                    <p>
                        <center>
                            Graduanda em Ciências da Computação (Estácio), com previsão
                            de formatura no 1º semestre de 2026. Atualmente é Estagiária
                            em Suporte na SEJUSP, conta com experiências nas áreas de
                            negociação, administração, relacionamento interpessoais
                            colaborativos e segurança da informação, além de cursos
                            complementares em desenvolvimento e programação para desenvolver
                            um trabalho cuidadoso e organizado com disciplina e visão lógica.
                    </p>
                    </center>
                    <br><br><br><br>
                </div>
            </div>

            <div class="Fund_ricardo">
                <div>
                    <a href="ricardo.html" target="_blank"><img src="Colaboradores/img/Ricardo.png" height="372"
                            width="254"></a>
                    <h2>
                        <center>Ricardo Eduardo</center>
                    </h2>
                    <p>
                        <center>
                            Graduando em Ciências da Computação (Estácio), com previsão
                            de formatura no 2º semestre de 2026. Atualmente é desenvolvedor
                            gráfico da @Rick_chees_coner, conta com experiências nas áreas
                            de designer, administração e comunicação, além dos cursos
                            extracurriculares introdutórios em Java, C#, Python, Banco
                            de Dados e HTML, para desenvolver um trabalho criativo e
                            persuasivo, com organização e foco nos resultados.
                    </p>
                    </center>
                    <br><br><br><br>
                </div>
            </div>

            <div class="Fund_silvia">
                <a href="silvia.html" target="_blank"><img src="Colaboradores/img/Silvia.png" height="372"
                        width="254" /></a>
                <h2>
                    <center>Sílvia Rausses</center>
                </h2>
                <p>
                    <center>
                        Graduanda em Análise e Desenvolvimento de Sistemas (Estácio),
                        com previsão de formatura no 1º semestre de 2025. Pós-graduada
                        em MBA em Gestão Estratégica de Negócios (Una - 2017), Graduada
                        em Processos Gerenciais (Una - 2015) e Bacharel em Design de
                        Moda (FUMEC - 2010). Atualmente é Estagiária em Teste de Software
                        na PRODEMGE, conta com experiências nas áreas de gestão empresarial,
                        designer,metodologia agil e processos de produção, para desenvolver
                        um trabalho estratégico, com dedicação na qualidade das entregas e no
                        cumprimento de prazos e metas.
                </p>
                </center>
                <br>
            </div>
        </div>
        <!-- Novos conteúdos deverão ser colocados acima deste comentário-->
    </div>
    </div>
    <!-- FIM DO CONTEÚDO DA PÁGINA-->
</body>

<?php include('footer.php'); ?>

<!-- Aba referente ao rodapé, utilizada normalmente para colocar imformaçÕes de fontes e construtores do site-->
<footer>
    <!-- Classe "rodape" criada para armazenar e manipular o radapé-->
    <div class="rodape" style="text-align: right;">
        Fundadores Guilherme / Mayara / Ricardo / Sílvia
    </div>
    <!-- FIM DO RODAPÉ-->
</footer>

<!-- FIM DA PÁGINA COMPLETA-->