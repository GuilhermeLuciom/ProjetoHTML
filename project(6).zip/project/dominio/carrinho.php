<?php
session_start(); // Inicia a sessão

// Verifica se foi enviado um pedido de remoção do carrinho
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['productId'])) {
    // Obtém o ID do produto a ser removido
    $productIdToRemove = $_POST['productId'];

    // Verifica se o produto está presente no carrinho
    if (isset($_SESSION['cart']) && isset($_SESSION['cart'][$productIdToRemove])) {
        // Remove o produto do carrinho
        unset($_SESSION['cart'][$productIdToRemove]);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho</title>
    <meta charset="utf-8">
    <!-- Aba style é feita em CSS, para modificar os estilos da página-->
    <link rel="stylesheet" href="ecommerce.css" type="text/css">
    <style>
        /* Estilos CSS aqui */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        .product-image {
            max-width: 100px;
            max-height: 100px;
        }
    </style>
</head>

<body>
    <?php include('header.php'); ?>
    <div class="Todo_conteudo">
        <div class="Titulo">
            <br>
            <h1>
                <center>Seu Carrinho</center>
            </h1>
            <hr>
        </div>

        <div class="carrinho-itens" style="width: 70%;margin-left: 15%;">
            <?php
            // Verifica se há produtos no carrinho
            if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
                echo '<table>';
                echo '<tr>';
                echo '<th>Selecionados</th>';
                echo '<th>Nome</th>';
                echo '<th>Salario esperado</th>';
                echo '<th>Remover</th>';
                echo '</tr>';
                $totalCost = 0; // Inicializa o custo total
                foreach ($_SESSION['cart'] as $productId => $product) {
                    $totalCost += floatval(str_replace(',', '.', $product['cost'])); // Soma o custo do produto ao total
                    echo '<tr>';
                    echo '<td><img class="product-image" src="' . $product['image'] . '" alt="' . $product['name'] . '"></td>';
                    echo '<td>' . $product['name'] . '</td>';
                    echo '<td>R$ ' . $product['cost'] . '</td>';
                    echo '<td>';
                    echo '<form method="post" action="">';
                    echo '<input type="hidden" name="productId" value="' . $productId . '">';
                    echo '<input class="botao1" style="width: 60%;" type="submit" value="Remover">';
                    echo '</form>';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '<tr>';
                echo '<td colspan="2"><strong>Total:</strong></td>';
                echo '<td colspan="2"><strong>R$ ' . number_format($totalCost, 2, ',', '.') . '</strong></td>'; // Formata o custo total
                echo '</tr>';
                echo '</table>';
                // Botão para finalizar compra
                echo '<br><br>';
                echo '<div style="text-align: right; margin-right: 50px;">';
                echo '<input class="botao1" type="submit" style=" width: 20%;" name="finalizarCompra" value="Finalizar Compra">';
                echo '</div>';

            } else {
                echo '<p>Seu carrinho está vazio.</p>';
            }
            ?>
        </div>

    </div>

    <?php include('footer.php'); ?>
</body>

<footer>
    <div class="rodape" style="text-align: right;">
        Fundadores Guilherme / Mayara / Ricardo / Sílvia
    </div>
</footer>

</html>